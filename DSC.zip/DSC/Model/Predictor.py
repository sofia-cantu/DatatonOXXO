import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point
from sklearn.metrics import classification_report, accuracy_score
from sklearn.model_selection import train_test_split, GridSearchCV
from xgboost import XGBClassifier
from sklearn.preprocessing import OneHotEncoder
from imblearn.over_sampling import SMOTE
from sklearn.neighbors import NearestNeighbors
from scipy.optimize import minimize

# ----------------------- FUNCIONES AUXILIARES -----------------------

def haversine(lat1, lon1, lat2, lon2):
    R = 6371
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    return R * (2 * np.arcsin(np.sqrt(a)))

def esta_en_mexico(lat, lon, gdf_mexico):
    punto = Point(lon, lat)
    return gdf_mexico.contains(punto).any()

# ----------------------- CARGA DE DATOS -----------------------

def cargar_shapefile_mexico(path):
    gdf = gpd.read_file(path)
    return gdf[gdf['admin'] == 'Mexico']

# ----------------------- ENTRENAMIENTO -----------------------

def entrenar_modelo(df):
    cat_cols = ["PLAZA_CVE", "NIVELSOCIOECONOMICO_DES", "ENTORNO_DES", "SEGMENTO_MAESTRO_DESC", "LID_UBICACION_TIENDA"]
    num_cols = ["MTS2VENTAS_NUM", "PUERTASREFRIG_NUM", "CAJONESESTACIONAMIENTO_NUM", "LATITUD_NUM", "LONGITUD_NUM"]

    df = df.dropna(subset=cat_cols + num_cols)
    encoder = OneHotEncoder(handle_unknown="ignore", sparse=False)
    X_cat_encoded = encoder.fit_transform(df[cat_cols])
    X_cat_df = pd.DataFrame(X_cat_encoded, columns=encoder.get_feature_names_out(cat_cols), index=df.index)

    X = pd.concat([df[num_cols], X_cat_df], axis=1)
    y = df["EXITO"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.2, random_state=42)
    X_train_bal, y_train_bal = SMOTE(random_state=42).fit_resample(X_train, y_train)

    param_grid = {
        'n_estimators': [50, 100],
        'max_depth': [3, 5],
        'learning_rate': [0.05, 0.1],
        'subsample': [0.8, 1.0],
        'colsample_bytree': [0.8, 1.0]
    }

    grid = GridSearchCV(XGBClassifier(eval_metric='logloss', random_state=42), param_grid, scoring='roc_auc', cv=5, n_jobs=-1)
    grid.fit(X_train_bal, y_train_bal)

    y_pred = grid.best_estimator_.predict(X_test)
    print(classification_report(y_test, y_pred))
    print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")

    return grid.best_estimator_, encoder, cat_cols, num_cols

# ----------------------- PREDICCIÓN -----------------------

def predecir_tienda_nueva(nueva_tienda, model, encoder, cat_cols, num_cols):
    nueva_df = pd.DataFrame([nueva_tienda])
    cat_encoded = encoder.transform(nueva_df[cat_cols])
    cat_df = pd.DataFrame(cat_encoded, columns=encoder.get_feature_names_out(cat_cols), index=nueva_df.index)
    X_new = pd.concat([nueva_df[num_cols], cat_df], axis=1)

    for col in model.get_booster().feature_names:
        if col not in X_new.columns:
            X_new[col] = 0
    X_new = X_new[model.get_booster().feature_names]

    return model.predict(X_new)[0], model.predict_proba(X_new)[0][1]

# ----------------------- COORDENADAS -----------------------

def predecir_con_coordenadas(lat, lon, df_features, knn, model, encoder, cat_cols, num_cols):
    _, idx = knn.kneighbors([[lat, lon]])
    tienda = df_features.iloc[idx[0][0]].to_dict()
    tienda.update({"LATITUD_NUM": lat, "LONGITUD_NUM": lon})
    return predecir_tienda_nueva(tienda, model, encoder, cat_cols, num_cols)

# ----------------------- OPTIMIZACIÓN -----------------------

def ventas_estimadas_con_ubicacion(x, model, tienda_base, encoder, cat_cols, num_cols):
    tienda = tienda_base.copy()
    tienda.update({"MTS2VENTAS_NUM": x[0], "PUERTASREFRIG_NUM": x[1], "CAJONESESTACIONAMIENTO_NUM": x[2]})
    _, prob = predecir_tienda_nueva(tienda, model, encoder, cat_cols, num_cols)
    return -prob

ENTORNOS_VALIDOS = {"Base", "Hogar", "Peatonal", "Receso"}

def predecir_y_optimizar_con_recomendacion(lat, lon, entorno, gdf_mexico, df_features, knn, model, encoder, cat_cols, num_cols):
    if entorno not in ENTORNOS_VALIDOS:
        raise ValueError(f"Entorno '{entorno}' no válido.")
    if not esta_en_mexico(lat, lon, gdf_mexico):
        raise ValueError("Ubicación fuera de México.")

    _, idx = knn.kneighbors([[lat, lon]])
    tienda_cercana = df_features.iloc[idx[0][0]]

    base = tienda_cercana.to_dict()
    base.update({"LATITUD_NUM": lat, "LONGITUD_NUM": lon, "ENTORNO_DES": entorno})

    x0 = [base["MTS2VENTAS_NUM"], base["PUERTASREFRIG_NUM"], base["CAJONESESTACIONAMIENTO_NUM"]]
    bounds = [(50, 200), (1, 10), (0, 10)]

    res = minimize(ventas_estimadas_con_ubicacion, x0, args=(model, base, encoder, cat_cols, num_cols), bounds=bounds, method='L-BFGS-B')
    mts2, puertas, cajones = res.x
    prob_opt = -res.fun

    base_pred, base_prob = predecir_tienda_nueva(base, model, encoder, cat_cols, num_cols)

    return {
        "pred_base": base_pred,
        "prob_base": base_prob,
        "optimizacion": {
            "mts2": mts2,
            "puertas": puertas,
            "cajones": cajones,
            "prob_optima": prob_opt
        }
    }
